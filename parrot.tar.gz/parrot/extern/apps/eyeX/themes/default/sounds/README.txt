/****************26/11/2007****************/
/*************CLEANUS*SOUND*THEME**********/
Hi Folks,

Here are my last sounds for Gnome. 
The complete sound theme for KDE can be found here 
http://kde-look.org/content/show.php/Cleanus?content=61245

If you have any job for the community or else, please contact me at martyn.clement@gmail.com, I'll be honored to work for any project.

Feel free to use these sounds for any usage, just let me know. 

Enjoy :)
Martyn